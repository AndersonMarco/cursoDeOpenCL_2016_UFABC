#ifndef commonFunctions_h
#define  commonFunctions_h
#include <stdlib.h>
#include <string.h>
char *concatStrings(const char *str1, const char *str2);
#endif
