#ifndef commonFunctions_h
#define  commonFunctions_h
#include <stdlib.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

char *concatStrings(const char *str1, const char *str2);

#ifdef __cplusplus
}
#endif    

#endif
